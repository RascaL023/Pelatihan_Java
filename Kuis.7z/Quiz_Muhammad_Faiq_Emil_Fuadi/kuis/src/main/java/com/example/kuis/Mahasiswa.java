package com.example.kuis;

public class Mahasiswa {
    private String nama;
    private int umur;

    public Mahasiswa(String n, int u){
        nama = n;
        umur = u;
    }

    public int getUmur(){return umur;}
    public String getNama(){return nama;}

    public void setUmur(int u){ umur = u; }
    public void setName(String n){ nama = n; }
}
