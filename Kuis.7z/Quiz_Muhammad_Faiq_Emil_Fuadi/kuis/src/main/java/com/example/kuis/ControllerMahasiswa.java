package com.example.kuis;

import java.util.List;
import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.kuis.Mahasiswa;

@Controller
@RequestMapping("/mahasiswa")
public class ControllerMahasiswa{
    List<Mahasiswa> mhs = new ArrayList<>();

    public ControllerMahasiswa(){
        mhs.add(new Mahasiswa("Asep", 20));
        mhs.add(new Mahasiswa("Joko", 20));
        mhs.add(new Mahasiswa("Budi", 20));
    }

    @GetMapping("/list")
    public String show(Model m){
        List<Mahasiswa> list = mhs;
        m.addAttribute("data", list);
        return "dataMahasiswa";
    }


}